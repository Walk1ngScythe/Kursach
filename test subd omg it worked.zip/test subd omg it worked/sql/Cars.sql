INSERT INTO Cars (model,category,status,for_disabled_person,price) VALUES
('Mersedes E200',3,0,0,10000),
('Hyndai Accent',2,1,1,2000),
('Ford Focus',1,0,0,4500),
('Opel Vectra B',1,0,0,3500),
('BMW M5',3,1,0,10000),
('VAZ 21053',2,0,0,1000);