INSERT INTO Roles (name_role) VALUES 
('admin'),
('user'),
('manager');
