INSERT INTO category_of_cars (name_category)  VALUES
('Comfort'),
('Economy'),
('Business');